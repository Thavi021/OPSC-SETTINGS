package com.example.googlemap_task2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class MainActivity2_home extends AppCompatActivity {

     ActionBar act;
     Intent intent;
    private CardView add, delete, items, view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity2_home);

        act = getSupportActionBar();
        act.setTitle("Main Page");

        add = (CardView) findViewById(R.id.Add);
        delete = (CardView) findViewById(R.id.deleteItems);
        items = (CardView) findViewById(R.id.Items);
        view = (CardView) findViewById(R.id.View);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2_home.this, MapsActivity.class);
                startActivity(intent);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent= new Intent(MainActivity2_home.this, view_fav.class);
               startActivity(intent);

            }
        });
        items.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity2_home.this, Setting_page.class);
                startActivity(intent);
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                System.exit(1);

            }
        });
    }


    }