package com.example.googlemap_task2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private EditText editTextEmail;
    private EditText editTextPassword;
    private TextView textViewRegister;
    private Button logBtn;
    private ProgressBar progressBar;
    public static  String currentUser;
    private ProgressDialog processDialog;
    Intent intent;
    ActionBar act;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        mAuth=FirebaseAuth.getInstance();

        act=getSupportActionBar();
        act.setTitle("Login");
        act.hide();



        editTextEmail = (EditText) findViewById(R.id.emailSignIn);
        editTextPassword = (EditText) findViewById(R.id.password);
        logBtn=(Button)findViewById(R.id.Login);
        textViewRegister=findViewById(R.id.register);
        progressBar = (ProgressBar) findViewById(R.id.progressbars);
        progressBar.setVisibility(View.GONE);
        processDialog = new ProgressDialog(this);

        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                intent= new Intent(MainActivity.this, register_person.class);
                startActivity(intent);

            }
        });
        logBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String name, password;
                 name = editTextEmail.getText().toString().trim();
                 password = editTextPassword.getText().toString();

                if (name.isEmpty())
                {
                    editTextEmail.setError("It's empty");
                    editTextEmail.requestFocus();
                    return;
                }
                if (password.isEmpty())
                {
                    editTextPassword.setError("It's Empty");
                    editTextPassword.requestFocus();
                    return;
                }
                try {

                    mAuth.signInWithEmailAndPassword(name,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task)
                        {
                            if(task.isSuccessful())
                            {
                                final Handler handler= new Handler();
                                final Runnable runnable=new Runnable() {
                                    @Override
                                    public void run()
                                    {
                                        progressBar.setVisibility(View.VISIBLE);
                                        Intent intent= new Intent(MainActivity.this, MainActivity2_home.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                };

                                handler.postDelayed(runnable,6000);

                            }else
                            {
                                Toast.makeText(MainActivity.this, "Something is wrong, check connection", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                }
                catch (Exception error)
                {
                    Toast.makeText(MainActivity.this, "Oups.Something is Wrong", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}