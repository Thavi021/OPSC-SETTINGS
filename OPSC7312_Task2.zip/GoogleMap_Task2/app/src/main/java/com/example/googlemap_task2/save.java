package com.example.googlemap_task2;

public class save {

    public String place;

    public save()
    {
    }

    public save(String place)
    {
        this.place = place;
    }

    public String getPlace()
    {
        return place;
    }

    public void setPlace(String place)
    {
        this.place = place;
    }
}
