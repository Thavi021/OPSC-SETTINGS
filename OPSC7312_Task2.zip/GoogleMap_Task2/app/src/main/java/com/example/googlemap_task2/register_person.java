package com.example.googlemap_task2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class register_person extends AppCompatActivity {

    private EditText editTextName,editTextPassword;
    public Button btnRegister;
    private ProgressBar progressBar;
    private ProgressDialog processDialog;
    Intent intent;
    ActionBar act;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_person);
        mAuth=FirebaseAuth.getInstance();

        editTextName = findViewById(R.id.emailRegister);
        editTextPassword = findViewById(R.id.passwordRegister);
        btnRegister=findViewById(R.id.registerBtn);

        progressBar = (ProgressBar) findViewById(R.id.progressbars);
        progressBar.setVisibility(View.GONE);
        processDialog = new ProgressDialog(this);

        act=getSupportActionBar();
        act.setTitle("Register With Us");
        act.hide();


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                final String name = editTextName.getText().toString().trim();
                final String password = editTextPassword.getText().toString();

                if(name.isEmpty())
                {
                    editTextName.setError("Please enter email");
                    editTextName.requestFocus();
                    return;
                }
                if(!Patterns.EMAIL_ADDRESS.matcher(name).matches())
                {
                    editTextName.setError(" enter valid email");
                    editTextName.requestFocus();
                }
                if(password.length()<6)
                {
                    editTextPassword.setError("Please make sure password character is more than 6");
                }

                if(password.isEmpty())
                {
                    editTextPassword.setError("Please enter The Email");
                    editTextPassword.requestFocus();
                    return;
                }

                try
                {
                if(!name.isEmpty() && !password.isEmpty()) {
                    mAuth.createUserWithEmailAndPassword(name, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()) {
                                user_account account = new user_account(name, password);
                                FirebaseDatabase.getInstance().getReference("user_account").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                        .setValue(account).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isComplete())
                                        {
                                            Toast.makeText(register_person.this, "Well You Are Registered", Toast.LENGTH_SHORT).show();

                                            final Handler handler= new Handler();
                                            final Runnable runnable=new Runnable() {
                                                @Override
                                                public void run()
                                                {
                                                    progressBar.setVisibility(View.VISIBLE);
                                                    Intent intent= new Intent(register_person.this, MainActivity.class);
                                                    startActivity(intent);
                                                    finish();
                                                }
                                            };

                                            handler.postDelayed(runnable,7000);

                                        } else {
                                            Toast.makeText(register_person.this, "Something is wrong, Check connection", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });

                            } else {
                                Toast.makeText(register_person.this, "Something is wrong", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });


                }
                }
                catch(Exception er)
                {
                    Toast.makeText(register_person.this, ""+er.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}