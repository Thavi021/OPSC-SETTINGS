package com.example.googlemap_task2;

public class Setting
{
    public String setting;

    public Setting()
    {
    }

    public Setting(String setting) {
        this.setting = setting;
    }

    public String getSetting()
    {
        return setting;
    }

    public void setSetting(String setting)
    {
        this.setting = setting;
    }
}
